<!-- App.vue -->
<template>
    <div id="app">
    <header>
    <div class="header-left">
    <h1>LTIMindtree</h1>
    </div>
    <div class="header-right">
    <img src="profile-icon.png" alt="Profile" class="profile-icon" />
    <label class="switch">
    <input type="checkbox" v-model="darkMode" />
    <span class="slider"></span>
    </label>
    </div>
    </header>
    <!-- Your main content goes here -->
    <footer>
    <!-- Empty space in the footer -->
    </footer>
    </div>
    </template>
    <script>
    export default {
     data() {
       return {
         darkMode: false,
       };
     },
    };
    </script>
    <style>
    /* Add your styling here */
    #app {
     text-align: center;
    }
    header {
     background-color: #333;
     color: white;
     padding: 1rem;
     display: flex;
     justify-content: space-between;
    }
    .header-left h1 {
     margin: 0;
    }
    .header-right {
     display: flex;
     align-items: center;
    }
    .profile-icon {
     width: 30px;
     height: 30px;
     margin-right: 10px;
    }
    .switch {
     position: relative;
     display: inline-block;
     width: 40px;
     height: 20px;
    }
    .switch input {
     opacity: 0;
     width: 0;
     height: 0;
    }
    .slider {
     position: absolute;
     cursor: pointer;
     top: 0;
     left: 0;
     right: 0;
     bottom: 0;
     background-color: #ccc;
     transition: 0.4s;
     border-radius: 20px;
    }
    .slider:before {
     position: absolute;
     content: '';
     height: 16px;
     width: 16px;
     left: 2px;
     bottom: 2px;
     background-color: white;
     transition: 0.4s;
     border-radius: 50%;
    }
    input:checked + .slider {
     background-color: #2196f3;
    }
    input:checked + .slider:before {
     transform: translateX(20px);
    }
    footer {
     height: 50px; /* Adjust height as needed */
     background-color: #eee;
     /* Additional styling for the footer if needed */
    }
    </style>