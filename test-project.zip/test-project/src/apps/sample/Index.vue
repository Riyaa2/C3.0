<template>
  <!-- Child Route of the App-->
  <router-view />
</template>

<script setup>

</script>
