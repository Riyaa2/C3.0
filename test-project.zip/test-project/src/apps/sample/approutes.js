import ShowApps from './views/pages/show-apps.vue'
import CreateApp from './views/pages/create-app.vue'
import CreateTable from './views/pages/create-table.vue'
const sampleroutes = [
      {
        path:'',
        name: 'Show-Apps',
        component: ShowApps
      },
      {
        path: '/create-app',
        name: 'Create-App',
        component: CreateApp
      },
      {
        path: '/create-table',
        name: 'Create-Table',
        component: CreateTable
      } 
    ]
  
export default sampleroutes
