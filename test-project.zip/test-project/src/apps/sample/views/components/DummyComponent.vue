<template>

    This is just a dummy component

</template>

<script setup>
</script>
