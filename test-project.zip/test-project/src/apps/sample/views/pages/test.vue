<template>
    <div class="q-pa-md">
      <q-stepper v-model="step" ref="stepper" color="primary" animated>
        <q-step
          :name="1"
          title="Application Details"
          icon="settings"
          :done="step > 1"
          style="min-height: 200px"
        >
          <q-page padding>
            <div class="q-pa-md">
              <q-card class="main-card" flat square>
                <q-card-section class="search-create-section">
                  <!-- Enhanced Form -->
                  <q-form @submit="onSubmit" @reset="onReset" class="q-gutter-md">
                    <q-input
                      filled
                      v-model="name"
                      label="Application Name *"
                      hint="Name of the Application"
                      dense
                      :standalone="isStandalone"
                      lazy-rules
                      :rules="[
                        (val) =>
                          (val && val.length > 0) || 'Please type something',
                      ]"
                    />
   
                    <q-input
                      filled
                      v-model="routepath"
                      label="Router Path *"
                      hint="Enter the routing path"
                      lazy-rules
                      :rules="[
                        (val) =>
                          (val && val.length > 0) || 'Please type something',
                      ]"
                    />
   
                    <q-input
                      filled
                      v-model="homecomponent"
                      label="Home Component *"
                      hint="Enter the homecomponent"
                      lazy-rules
                      :rules="[
                        (val) =>
                          (val && val.length > 0) || 'Please type something',
                      ]"
                    />
   
                   
   
                    <q-input
                      filled
                      v-model="describes"
                      label="Description *"
                      hint="Enter the description of app"
                      lazy-rules
                      :rules="[
                        (val) =>
                          (val && val.length > 0) || 'Please type something',
                      ]"
                    />
                  </q-form>
                </q-card-section>
              </q-card>
              <!-- </q-layout> -->
            </div>
          </q-page>
        </q-step>
   
        <q-step
          :name="2"
          title="Choose Schema"
          icon="create_new_folder"
          :done="step > 2"
          style="min-height: 200px"
        >
          <q-page v-if="schemavar == 0">
                <h4>Seimen feels like this page is empty!</h4>
          </q-page>
          <q-page v-if="schemavar == 1">
            <q-form>
              <label>Schema Name</label>
              <q-input
                      filled
                      v-model="homecomponent"
                      label="Schema Name"
                      hint="Enter schema name"
                      lazy-rules
                      :rules="[
                        (val) =>
                          (val && val.length > 0) || 'Please type something',
                      ]"
                    />
   
                   
                    <label>Schema Description</label>
                    <q-input
                      filled
                      v-model="describes"
                      label="Schema Description *"
                      hint="Enter the description of Schema"
                      lazy-rules
                      :rules="[
                        (val) =>
                          (val && val.length > 0) || 'Please type something',
                      ]"
                    />
            </q-form>
          </q-page>
          <q-page v-if="schemavar == 2">
            <div class="row">
            <div class="col">
              <label>Select Existing Schema</label>
              <q-select
                standout="bg-grey text-black"
                v-model="schema"
                :options="schemas"
                label="Select Default Schema"
              />
            </div>
            <!-- <div class="col">
              <q-btn to="/create-table" rounded color="blue" class="q-ml-lg q-mt-sm">
                <q-icon left size="2em" name="add" />
                <div>Create Table</div>
              </q-btn>
            </div> -->
          </div>
          </q-page>
   
        </q-step>
   
   
        <q-step
          :name="3"
          title="Create Table"
          icon="add_comment"
          style="min-height: 200px"
        >
          <h4><label>Schema-2024_Name</label></h4>
          <h5><label>No tables available</label></h5>
          <div class="q-pa-md">
              <q-btn label="Add Table" color="primary" @click="openDialog"/>
              <q-dialog v-model="dialog">
                <q-card>
   
                  <q-card-actions align="right">
                    <q-btn no-caps label="Close" color="primary" @click="closeDialog"/>
                  </q-card-actions>
                </q-card>
              </q-dialog>
          </div>
       
        </q-step>
   
        <template v-slot:navigation>
          <q-stepper-navigation>
            <q-btn
              @click="$refs.stepper.next()"
              color="primary"
              :label="step === 3 ? 'Finish' : 'Continue'"
            />
            <q-btn
              v-if="step > 1"
              flat
              color="primary"
              @click="$refs.stepper.previous()"
              label="Back"
              class="q-ml-sm"
            />
          </q-stepper-navigation>
        </template>
   
        <template v-slot:message>
          <q-banner v-if="step === 1" style="background-color: #F9C74F;" class=" text-white q-px-lg">
            Basic Application Detials
          </q-banner>
          <q-banner v-if="step === 2" style="background-color: #F9C74F;" class=" text-white q-px-lg">
     
            <div class="row">
            <div class="col-lg-8">
              Choose Schema
            </div>
            <div class="col-lg-2">
              <q-btn to="" @click="newSchemaPage" color="grey" class="q-ml-lg q-mt-sm">
                <q-icon left size="2em" name="add" />
                <div>New Schema</div>
              </q-btn>
            </div>
            <div class="col-lg-2">
              <q-btn to="" @click="existingSchemaPage" color="grey" class="q-ml-lg q-mt-sm">
                <q-icon left size="2em" name="edit" />
                <div>Existing Schema</div>
              </q-btn>
            </div>
          </div>
          </q-banner>
          <q-banner v-else-if="step === 3" style="background-color: #F9C74F;" class=" text-white q-px-lg">
            Create Table for Application
          </q-banner>
        </template>
      </q-stepper>
    </div>
  </template>
   
  <script>
  import { ref } from "vue";
   
   
  export default {
   
    data() {
      return {
        schemavar : 0,
        options: ["int", "float", "varchar", "boolean"],
        schemas: [
          "Schema1",
          "Schema2",
          "Schema3",
          "Schema4",
          "Schema5",
          "Schema6",
        ],
        schema: "",
        column: {
          name: "",
          type: "",
          primarykey: "",
          foreignkey: "",
          uniquekey: "",
          check: "",
        },
        columns: [], // Array to store added columns
        tableColumns: [
          { name: "name", label: "Column Name", align: "left", field: "name" },
          { name: "type", label: "Data Type", align: "left", field: "type" },
          {
            name: "primarykey",
            label: "Primary-Key",
            align: "left",
            field: "primarykey",
          },
          {
            name: "foreignkey",
            label: "Foreign-Key",
            align: "left",
            field: "foreignkey",
          },
          {
            name: "uniquekey",
            label: "Unique-Key",
            align: "left",
            field: "uniquekey",
          },
          {
            name: "check",
            label: "Check",
            align: "left",
            field: "check",
          },
        ],
      };
    },
    methods: {
      openDialog(){
        this.dialog=true;
      },
      closeDialog(){
        this.dialog=false;
      },
      newSchemaPage() {
       this.schemavar = 1;
     },
     existingSchemaPage() {
       this.schemavar = 2;
     },
      addColumn() {
        // Add the current column to the columns array
        this.columns.push({ ...this.column });
   
        // Clear the form fields for the next input
        this.column = {
          name: "",
          type: "",
          primarykey: "",
          foreignkey: "",
          uniquekey: "",
          check: "",
        };
      },
      clearColumns() {
        // Clear all columns
        this.columns.pop();
      },
    },
   
    setup() {
      return {
        step: ref(1),
        dialog: ref(false),
        shape: ref('line')
      };
    },
  };
  </script>
  <style lang="scss">
  .q-stepper__tab .col-grow .flex .items-center .no-wrap .relative-position .hide{
    display: none;
    height: 0px;
   
  }
  @import "../../assets/css/sample.scss";
  </style>