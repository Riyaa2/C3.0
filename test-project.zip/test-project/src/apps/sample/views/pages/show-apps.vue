<template>
  <q-page padding>
    <q-table
      grid
      flat
      bordered
      :card-container-class="cardContainerClass"
      :rows="rows"
      :columns="columns"
      row-key="name"
      :filter="filter"
      hide-header
      hide-bottom
      v-model:pagination="pagination"
      style="height: 80vh"
    >
      <template v-slot:top-left>
        <h5>Applications</h5>
        <q-btn to="/create-app" rounded color="blue" class="q-ml-lg">
          <q-icon left size="2em" name="add" />
          <div>Create</div>
        </q-btn>
      </template>
      <template v-slot:top-right>
        <q-input dense debounce="600" v-model="filter" placeholder="Search">
          <template v-slot:append>
            <q-icon name="search" />
          </template>
        </q-input>
      </template>
      <template v-slot:item="props">
        <div class="q-pa-xs col-xs-12 col-sm-6 col-md-4">
          <q-card class="my-card bg-blue-14 text-white">
            <q-card-section horizontal>
              <q-card-actions vertical class="q-pa-lg">
                <div class="text-h6">{{ props.row.name }}</div>
                <div class="text-subtitle2">{{ props.row.version }}</div>
              </q-card-actions>

              <q-card-actions
                vertical-right
                style="
                  position: absolute;
                  align-items: normal;
                  bottom: 30px;
                  right: -20px;
                "
              >
                <q-item-section avatar>
                  <q-icon name="info_outlined" />
                </q-item-section>
              </q-card-actions>
            </q-card-section>
          </q-card>
        </div>
      </template>
    </q-table>
  </q-page>
  <!-- <q-page-container>
    <RouterView />
  </q-page-container> -->
</template>

<script>
import { ref } from "vue";

//This for application listing
const columns = [
  {
    name: "Application Name",
    required: true,
    label: "App-Name",
    align: "left",
    field: (row) => row.name,
    format: (val) => `${val}`,
    sortable: true,
  },
  {
    name: "Application Version",
    align: "center",
    label: "App-Version",
    field: (row) => row.version,
    format: (val) => `${val}`,
    sortable: true,
  },
];

const rows = [
  {
    name: "Braio",
    version: "Version 3.0",
    required: true,
  },
  {
    name: "iSGS",
    version: "Version 2.0",
    required: true,
  },
  {
    name: "Opsight",
    version: "Version 2.0",
    required: true,
  },
  {
    name: "iTD",
    version: "Version 5.0",
    required: true,
  },
  {
    name: "Ask-Jovi",
    version: "Version 1.0",
    required: true,
  },
  {
    name: "Bot-Governece",
    version: "Version 1.0",
    required: true,
  },
  {
    name: "AI-ML Md",
    version: "Version 3.0",
    required: true,
  },
  {
    name: "Ask-Jovi",
    version: "Version 1.0",
    required: true,
  },
  {
    name: "Bot-Governece",
    version: "Version 1.0",
    required: true,
  },
  {
    name: "AI-ML Md",
    version: "Version 3.0",
    required: true,
  },
  {
    name: "Ask-Jovi",
    version: "Version 1.0",
    required: true,
  },
  {
    name: "Bot-Governece",
    version: "Version 1.0",
    required: true,
  },
  {
    name: "AI-ML Md",
    version: "Version 3.0",
    required: true,
  },
  {
    name: "Ask-Jovi",
    version: "Version 1.0",
    required: true,
  },
  {
    name: "Bot-Governece",
    version: "Version 1.0",
    required: true,
  },
  {
    name: "AI-ML Md",
    version: "Version 3.0",
    required: true,
  },
];

//end of application listing

export default {
  setup() {
    return {
      filter: ref(""),
      columns,
      rows,
      pagination: {
        rowsPerPage: 25000,
        sortBy: "updated_at",
        descending: true,
      },
    };
  },
};
</script>

  <style lang="scss">
  @import "../../assets/css/sample.scss";
  </style>
