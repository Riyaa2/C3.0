<template>
  <div class="q-pa-md">
    <q-splitter
      v-model="splitterModel"
      unit="px"
      style="height: 500px"
    >

          <template v-slot:before >
          <div class="q-pa-md left ">
              <div class="text-h6 q-mb-md">Form Flow</div>
              <!--<div v-for="n in 20" :key="n" class="q-my-md">{{ n }}. Hi Riya</div>-->
              <div>
                  <q-stepper
                      v-model="step"
                      vertical
                      color="primary"
                      animated>
         
      <q-step
        :name="1"
        title="Application Details"
        icon="settings"
        :done="step > 1"
        style="min-height: 100px"
      >
        
          <q-stepper-navigation>
          <q-btn @click="navigateToStep2(2, true)" color="primary" label="Continue" />
          </q-stepper-navigation>
      </q-step>
 
      <q-step
        :name="2"
        title="Choose Schema"
        icon="create_new_folder"
        :done="step > 2"
        style="min-height: 100px"
      >
          <q-stepper-navigation>
          <q-btn @click="navigateToStep3(3, true)" color="primary" label="Continue" />
          <q-btn flat @click="navigateToStep1(1,true)" color="primary" label="Back" class="q-ml-sm" />
          </q-stepper-navigation>
      </q-step>
 
 
      <q-step
        :name="3"
        title="Create Table"
        icon="add_comment"
        :done="step > 3"
        style="min-height: 100px"
      >

          <q-stepper-navigation>
          
          <q-btn flat @click="navigateToStep2(2,true)" color="primary" label="Back" class="q-ml-sm" />
          </q-stepper-navigation>
     
      </q-step>
    </q-stepper>
  </div>

              </div>

         
          </template>
 

      <template v-slot:after>
        <div class="q-pa-md">
          <div class="text-h5 q-mb-md">Fill Details </div>
          <!--<div v-for="n in 20" :key="n" class="q-my-md">{{ n }}. Hi Puja</div>-->
          <div v-if="showStep1">
            <q-page padding>
            <div class="q-pa-md">
              <q-card class="main-card" flat square>
                <q-card-section class="search-create-section">
                  <!-- Enhanced Form -->
                  <q-form @submit="onSubmit" @reset="onReset" class="q-gutter-md">
                    <q-input
                      filled
                      v-model="name"
                      label="Application Name *"
                      hint="Name of the Application"
                      dense
                      :standalone="isStandalone"
                      lazy-rules
                      :rules="[
                        (val) =>
                          (val && val.length > 0) || 'Please type something',
                      ]"
                    />
   
                    <q-input
                      filled
                      v-model="routepath"
                      label="Router Path *"
                      hint="Enter the routing path"
                      lazy-rules
                      :rules="[
                        (val) =>
                          (val && val.length > 0) || 'Please type something',
                      ]"
                    />
   
                    <q-input
                      filled
                      v-model="homecomponent"
                      label="Home Component *"
                      hint="Enter the homecomponent"
                      lazy-rules
                      :rules="[
                        (val) =>
                          (val && val.length > 0) || 'Please type something',
                      ]"
                    />
   
                   
   
                    <q-input
                      filled
                      v-model="describes"
                      label="Description *"
                      hint="Enter the description of app"
                      lazy-rules
                      :rules="[
                        (val) =>
                          (val && val.length > 0) || 'Please type something',
                      ]"
                    />
                  </q-form>
                </q-card-section>
              </q-card>
              <!-- </q-layout> -->
            </div>
          </q-page>
          </div>

          <div v-if="showStep2">
            <q-banner v-if="step === 2" style="background-color: #F9C74F;" class=" text-white q-px-lg">
     
            <div class="row">
            <div class="col-lg-8">
              Choose Schema
            </div>
            <div class="col-lg-2">
              <q-btn to="" @click="newSchemaPage" color="grey" class="q-ml-lg q-mt-sm">
                <q-icon left size="2em" name="add" />
                <div>New Schema</div>
              </q-btn>
            </div>
            <div class="col-lg-2">
              <q-btn to="" @click="existingSchemaPage" color="grey" class="q-ml-lg q-mt-sm">
                <q-icon left size="2em" name="edit" />
                <div>Existing Schema</div>
              </q-btn>
            </div>
          </div>
          </q-banner>
            <q-page v-if="schemavar == 0">
                <h4>Select options</h4>
          </q-page>
          <q-page v-if="schemavar == 1">
            <q-form>
              <label>Schema Name</label>
              <q-input
                      filled
                      v-model="homecomponent"
                      label="Schema Name"
                      hint="Enter schema name"
                      lazy-rules
                      :rules="[
                        (val) =>
                          (val && val.length > 0) || 'Please type something',
                      ]"
                    />
   
                   
                    <label>Schema Description</label>
                    <q-input
                      filled
                      v-model="describes"
                      label="Schema Description *"
                      hint="Enter the description of Schema"
                      lazy-rules
                      :rules="[
                        (val) =>
                          (val && val.length > 0) || 'Please type something',
                      ]"
                    />
            </q-form>
          </q-page>
          <q-page v-if="schemavar == 2">
            <div class="row">
            <div class="col">
              <label>Select Existing Schema</label>
              <q-select
                standout="bg-grey text-black"
                v-model="schema"
                :options="schemas"
                label="Select Default Schema"
              />
            </div>
            <!-- <div class="col">
              <q-btn to="/create-table" rounded color="blue" class="q-ml-lg q-mt-sm">
                <q-icon left size="2em" name="add" />
                <div>Create Table</div>
              </q-btn>
            </div> -->
          </div>
          </q-page>
          </div>
          
          <div v-if="showStep3">
            <h4><label>Schema-2024_Name</label></h4>
          <h5><label>No tables available</label></h5>
          <div class="q-pa-md">
              <q-btn label="Add Table" color="primary" @click="openDialog" :done="step > 1" />
              <q-dialog
                v-model="dialog"
                full-width
                full-height
              >
                <q-card>
                  <q-card-section>
                    <label><h5>Create Table</h5></label>
                  </q-card-section>
                  
                  <q-card-section>
                    <q-stepper
      v-model="step"
      ref="stepper"
      active-color="secondary"
      inactive-color="grey-7"
      header-class="text-bold"
      animated
    >
      <q-step
        :name="1"
        title="General"
        icon="settings"
        color="grey"
        :done="step > 1"
        
      >
        <q-input
          v-model="name"
          label="Name of the Table"
          dense
        />
      </q-step>

      <q-step
        :name="2"
        title="Columns"
        header-class="text-bold"
        animated
        icon="create_new_folder"
        :done="step > 2"
      >
        <q-card>
          <q-card-section>
            <table class="q-table">
              <thead>
                <tr>
                  <th>Column Name</th>
                  <th>Data Type</th>
                  <th>Primary Key</th>
                  <th>Foreign Key</th>
                  <th>Not Null</th>
                  <th>Unique</th>
                  <th>
                    <q-icon
                      name="add"
                      class="cursor-pointer"
                      @click="addRow"
                      style="font-size: 25px"
                    />
                  </th>
                </tr>
              </thead>
              <tbody class="align-center">
                <tr v-for="column in columns" :key="column.id">
                  <td>
                    <q-input v-model="column.name" />
                  </td>
                  <td>
                    <q-select v-model="column.dataType" :options="dataTypes" />
                  </td>
                  <td>
                    <q-toggle v-model="column.isPrimaryKey" />
                  </td>
                  <td>
                    <q-toggle v-model="column.isForeignKey" />
                  </td>
                  <td>
                    <q-toggle
                      v-model="column.notNull"
                      :disable="column.isPrimaryKey"
                    />
                  </td>
                  <td>
                    <q-toggle
                      v-model="column.unique"
                      :disable="column.isPrimaryKey"
                    />
                  </td>

                  <td>
                    <q-icon
                      name="delete"
                      class="cursor-pointer"
                      @click="removeRow(column)"
                    />
                  </td>
                </tr>
              </tbody>
            </table>
          </q-card-section>
        </q-card>
      </q-step>

      <template v-slot:navigation>
        <q-stepper-navigation>
          <q-btn
            @click="$refs.stepper.next()"
            color="secondary"
            :label="step === 2 ? 'Create' : 'Continue'"
          />
          <q-btn
            v-if="step > 1"
            flat
            color="black"
            @click="$refs.stepper.previous()"
            label="Back"
            class="q-ml-sm"
          />
        </q-stepper-navigation>
      </template>
                    </q-stepper>
                  </q-card-section>

                  <q-card-actions align="right" class="bg-white text-teal">
                    <q-btn flat label="Close" v-close-popup />
                  </q-card-actions>
                </q-card>
              </q-dialog>
          </div>
              
          </div>

        </div>
      </template>


      <template v-slot:navigation>
          <q-stepper-navigation>
            <q-btn
              @click="$refs.stepper.next()"
              color="primary"
              :label="step === 3 ? 'Finish' : 'Continue'"
            />
            <q-btn
              v-if="step > 1"
              flat
              color="primary"
              @click="$refs.stepper.previous()"
              label="Back"
              class="q-ml-sm"
            />
          </q-stepper-navigation>
        </template>
   
        <template v-slot:message>
          <q-banner v-if="step === 1" style="background-color: #F9C74F;" class=" text-white q-px-lg">
            Basic Application Detials
          </q-banner>
          <q-banner v-if="step === 2" style="background-color: #F9C74F;" class=" text-white q-px-lg">
     
            <div class="row">
            <div class="col-lg-8">
              Choose Schema
            </div>
            <div class="col-lg-2">
              <q-btn to="" @click="newSchemaPage" color="grey" class="q-ml-lg q-mt-sm">
                <q-icon left size="2em" name="add" />
                <div>New Schema</div>
              </q-btn>
            </div>
            <div class="col-lg-2">
              <q-btn to="" @click="existingSchemaPage" color="grey" class="q-ml-lg q-mt-sm">
                <q-icon left size="2em" name="edit" />
                <div>Existing Schema</div>
              </q-btn>
            </div>
          </div>
          </q-banner>
          <q-banner v-else-if="step === 3" style="background-color: #F9C74F;" class=" text-white q-px-lg">
            Create Table for Application
          </q-banner>
        </template>

  </q-splitter>
  </div>
</template>
 
<script>
import { ref } from "vue";
 
 
export default {
 
  data() {
    return {

      schemavar : 0,
      options: ["int", "float", "varchar", "boolean"],
      schemas: [
        "Schema1",
        "Schema2",
        "Schema3",
        "Schema4",
        "Schema5",
        "Schema6",
      ],
      schema: "",
      columns: [
        {
          id: 1,
          name: "",
          dataType: "",
          isForeignKey: false,
          isPrimaryKey: false,
          notNull: false,
          unique: false,
        },
      ],
      dataTypes: ["int", "char", "varchar"],
      // column: {
      //   name: "",
      //   type: "",
      //   primarykey: "",
      //   foreignkey: "",
      //   uniquekey: "",
      //   check: "",
      // },
      // columns: [], // Array to store added columns
      // tableColumns: [
      //   { name: "name", label: "Column Name", align: "left", field: "name" },
      //   { name: "type", label: "Data Type", align: "left", field: "type" },
      //   {
      //     name: "primarykey",
      //     label: "Primary-Key",
      //     align: "left",
      //     field: "primarykey",
      //   },
      //   {
      //     name: "foreignkey",
      //     label: "Foreign-Key",
      //     align: "left",
      //     field: "foreignkey",
      //   },
      //   {
      //     name: "uniquekey",
      //     label: "Unique-Key",
      //     align: "left",
      //     field: "uniquekey",
      //   },
      //   {
      //     name: "check",
      //     label: "Check",
      //     align: "left",
      //     field: "check",
      //   },
      // ],
    };
  },
  methods: {
    navigateToStep1(st,status){
          this.showStep1 = status;
          this.showStep2 = !status;
          this.step = st;
      },
      navigateToStep2(st,status){
          this.showStep1 = !status;
          this.showStep2 = status;
          this.showStep3 = !status;
          this.step = st;
      },
      navigateToStep3(st,status){
          this.showStep2 = !status;
          this.showStep3 = status;
          this.step = st;
      },
    openDialog(){
      this.dialog=true;
    },
    closeDialog(){
      this.dialog=false;
    },
    newSchemaPage() {
     this.schemavar = 1;
   },
   existingSchemaPage() {
     this.schemavar = 2;
   },
   addRow() {
      this.columns.push({
        id: this.columns.length + 1,
        name: "",
        dataType: "",
        length: null,
        isPrimaryKey: false,
        notNull: false,
        unique: false,
      });
    },
    removeRow(row) {
      const index = this.columns.indexOf(row);
      if (index !== -1) {
        this.columns.splice(index, 1);
      }
    },
    showLengthInput(dataType) {
      return ["varchar"].includes(dataType.toLowerCase());
    },
  },
  setup() {
    return {
      step: ref(1),
    };
    // addColumn() {
    //   // Add the current column to the columns array
    //   this.columns.push({ ...this.column });
 
    //   // Clear the form fields for the next input
    //   this.column = {
    //     name: "",
    //     type: "",
    //     primarykey: "",
    //     foreignkey: "",
    //     uniquekey: "",
    //     check: "",
    //   };
    // },
    // clearColumns() {
    //   // Clear all columns
    //   this.columns.pop();
    // },
  },
 
  setup() {
    return {
      step: ref(1),
      dialog: ref(false),
      shape: ref('line'),
      showStep1: ref(true),
    showStep2: ref(false),
    showStep4: ref(false)
    };
  },
};
</script>
<style lang="scss">
.q-stepper__tab .col-grow .flex .items-center .no-wrap .relative-position .hide{
  display: none;
  height: 0px;
 
}
@import "../../assets/css/sample.scss";
</style>