<!-- AddColumn.vue -->
<template>
    <q-page style="max-width: 80%" padding>
      <q-container>
        <!-- Form to input column details -->
        <q-form @submit.prevent="addColumn">
          <q-input
            class="q-pa-md"
            v-model="newtablename"
            label="Table Name"
            outlined
          />
          <q-input
            class="q-pa-md"
            v-model="column.name"
            label="Column Name"
            outlined
          />
          <q-select
            class="q-pa-md"
            outlined
            v-model="column.type"
            :options="options"
            label="Data Type"
          />
          <div class="row">
            <div class="col q-pa-md q-ml-md">
              <label>Primary Key</label>
            </div>
            <div class="col">
              <q-radio
                v-model="column.primarykey"
                val="true"
                label="True"
                color="green"
              />
              <q-radio
                v-model="column.primarykey"
                val="false"
                label="False"
                color="red"
              />
            </div>
          </div>
  
          <div class="row">
            <div class="col q-pa-md q-ml-md"><label>Foreign-Key</label></div>
            <div class="col">
              <q-radio
                v-model="column.foreignkey"
                val="true"
                label="True"
                color="green"
              />
              <q-radio
                v-model="column.foreignkey"
                val="false"
                label="False"
                color="red"
              />
            </div>
          </div>
  
          <div class="row">
            <div class="col q-pa-md q-ml-md"><label>Unique-Key</label></div>
            <div class="col">
              <q-radio
                v-model="column.uniquekey"
                val="true"
                label="True"
                color="green"
              />
              <q-radio
                v-model="column.uniquekey"
                val="false"
                label="False"
                color="red"
              />
            </div>
          </div>
  
          <div class="row">
            <div class="col q-pa-md q-ml-md"><label>Check</label></div>
            <div class="col">
              <q-radio
                v-model="column.check"
                val="true"
                label="True"
                color="green"
              />
              <q-radio
                v-model="column.check"
                val="false"
                label="False"
                color="red"
              />
            </div>
          </div>
  
          <q-btn
            class="q-ma-md"
            style="right: -84%"
            type="submit"
            label="Add Column"
            color="primary"
          />
        </q-form>
  
        <!-- Display table with column data -->
        <q-table
          :rows="columns"
          :columns="tableColumns"
          row-key="name"
          :rows-dense="false"
          bordered
        >
          <template v-slot:top-right>
            <q-btn @click="clearColumns" label="Clear Columns" color="negative" />
          </template>
        </q-table>
      </q-container>
    </q-page>
  </template>
  
  <script>
  export default {
    data() {
      return {
        newtablename: "",
        options: ["int", "float", "varchar", "boolean"],
        column: {
          name: "",
          type: "",
          primarykey: "",
          foreignkey: "",
          uniquekey: "",
          check: "",
        },
        columns: [], // Array to store added columns
        tableColumns: [
          { name: "name", label: "Column Name", align: "left", field: "name" },
          { name: "type", label: "Data Type", align: "left", field: "type" },
          {
            name: "primarykey",
            label: "Primary-Key",
            align: "left",
            field: "primarykey",
          },
          {
            name: "foreignkey",
            label: "Foreign-Key",
            align: "left",
            field: "foreignkey",
          },
          {
            name: "uniquekey",
            label: "Unique-Key",
            align: "left",
            field: "uniquekey",
          },
          {
            name: "check",
            label: "Check",
            align: "left",
            field: "check",
          },
        ],
      };
    },
    methods: {
      addColumn() {
        // Add the current column to the columns array
        this.columns.push({ ...this.column });
  
        // Clear the form fields for the next input
        this.column = {
          name: "",
          type: "",
          primarykey: "",
          foreignkey: "",
          uniquekey: "",
          check: "",
        };
      },
      clearColumns() {
        // Clear all columns
        this.columns.pop();
      },
    },
  };
  </script>
  