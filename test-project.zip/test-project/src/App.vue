<script setup>
import JoritzMainLayout from './views/JoritzMainLayout.vue'

</script>

<template>
  <joritz-main-layout></joritz-main-layout>
</template>

<style scoped>

</style>
